var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'leshane',
applicationName: 'fabric',
appUid: '2h3rPCQqjm7HwS2Yzj',
tenantUid: 'PYSwjQQsVH46gYlrrD',
deploymentUid: 'a41fb5c4-31e8-4a61-a818-1bdba5dd3a0c',
serviceName: 'constellation',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'constellation-dev-app', timeout: 6}
try {
  const userHandler = require('./server.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
