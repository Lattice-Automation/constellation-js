var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'leshane',
applicationName: 'fabric',
appUid: '2h3rPCQqjm7HwS2Yzj',
tenantUid: 'PYSwjQQsVH46gYlrrD',
deploymentUid: '895b48ad-fd21-4e36-b1f2-903d7e905f4c',
serviceName: 'constellation',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'constellation-dev-app', timeout: 6}
try {
  const userHandler = require('./server.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
