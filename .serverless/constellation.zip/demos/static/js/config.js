const types = {
  NODE: 'NODE',
  EDGE: 'EDGE'
};
var config = {
  representation: types.EDGE
};

export {config};
